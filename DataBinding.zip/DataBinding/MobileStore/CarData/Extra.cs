﻿namespace MobileStore.CarData
{
    public class Extra
    {
        public string Name { get; set; }

        public override string ToString()
        {
            return this.Name.ToString();
        }
    }
}