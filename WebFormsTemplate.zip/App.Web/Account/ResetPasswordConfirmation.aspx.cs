﻿using System.Web.UI;

namespace App.Web.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}